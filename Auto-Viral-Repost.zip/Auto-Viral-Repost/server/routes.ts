import type { Express } from "express";
import type { Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { api, errorSchemas } from "@shared/routes";
import { z } from "zod";
import { registerChatRoutes } from "./replit_integrations/chat";
import { registerImageRoutes } from "./replit_integrations/image";
import { registerAudioRoutes } from "./replit_integrations/audio";
import { openai } from "./replit_integrations/image"; // Reusing client from image integration

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup Auth (Passport)
  setupAuth(app);

  // Register Integration Routes
  registerChatRoutes(app);
  registerImageRoutes(app);
  registerAudioRoutes(app);

  // --- API Routes ---

  // Connected Accounts
  app.get(api.connectedAccounts.list.path, async (req, res) => {
    if (!req.user) return res.status(401).json({ message: "Unauthorized" });
    const accounts = await storage.getConnectedAccounts(req.user.id);
    res.json(accounts);
  });

  app.post(api.connectedAccounts.connect.path, async (req, res) => {
    if (!req.user) return res.status(401).json({ message: "Unauthorized" });
    try {
      const input = api.connectedAccounts.connect.input.parse(req.body);
      
      // Enforce Free Plan Limit
      if (req.user.subscriptionPlan === "free") {
        const accounts = await storage.getConnectedAccounts(req.user.id);
        if (accounts.length >= 1) {
          return res.status(403).json({ message: "Free plan allows only 1 connected account. Upgrade to Pro!" });
        }
      }

      const account = await storage.createConnectedAccount({
        ...input,
        userId: req.user.id,
      });
      res.status(201).json(account);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  app.delete(api.connectedAccounts.delete.path, async (req, res) => {
    if (!req.user) return res.status(401).json({ message: "Unauthorized" });
    await storage.deleteConnectedAccount(Number(req.params.id));
    res.status(204).send();
  });

  // Clips
  app.get(api.clips.list.path, async (req, res) => {
    if (!req.user) return res.status(401).json({ message: "Unauthorized" });
    const clips = await storage.getClips(req.user.id);
    res.json(clips);
  });

  app.post(api.clips.create.path, async (req, res) => {
    if (!req.user) return res.status(401).json({ message: "Unauthorized" });
    try {
      const input = api.clips.create.input.parse(req.body);

      // Enforce Daily Limit (Mock logic: just check credits)
      // In a real app, we'd reset credits daily via cron
      if (req.user.subscriptionPlan === "free" && (req.user.credits || 0) <= 0) {
        return res.status(403).json({ message: "Daily clip limit reached. Upgrade to Pro!" });
      }

      // Decrement credits for free users
      if (req.user.subscriptionPlan === "free") {
         await storage.updateUser(req.user.id, { credits: (req.user.credits || 1) - 1 });
      }

      const clip = await storage.createClip({
        ...input,
        userId: req.user.id,
        status: "processing",
        title: "Processing Video...",
      });

      // MOCK PROCESSING: Start async job
      // In a real app, this would be a queue
      processClipAsync(clip.id, input.originalUrl);

      res.status(201).json(clip);
    } catch (err) {
       if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  app.get(api.clips.get.path, async (req, res) => {
    if (!req.user) return res.status(401).json({ message: "Unauthorized" });
    const clip = await storage.getClip(Number(req.params.id));
    if (!clip) return res.status(404).json({ message: "Clip not found" });
    res.json(clip);
  });

  // Reposts
  app.get(api.reposts.list.path, async (req, res) => {
    if (!req.user) return res.status(401).json({ message: "Unauthorized" });
    const reposts = await storage.getReposts(req.user.id);
    res.json(reposts);
  });

  // User Plan Update
  app.get(api.users.list.path, async (req, res) => {
    if (!req.user || req.user.role !== 'admin') return res.status(403).json({ message: "Forbidden" });
    const users = await storage.getAllUsers();
    res.json(users);
  });

  app.patch(api.users.updatePlan.path, async (req, res) => {
    if (!req.user) return res.status(401).json({ message: "Unauthorized" });
    try {
      const { subscriptionPlan } = api.users.updatePlan.input.parse(req.body);
      const updatedUser = await storage.updateUser(req.user.id, { 
        subscriptionPlan,
        credits: subscriptionPlan === 'pro' ? 9999 : 1 // Reset/Update credits
      });
      res.json(updatedUser);
    } catch (err) {
      res.status(400).json({ message: "Invalid Plan" });
    }
  });

  return httpServer;
}

// Mock async processing function
async function processClipAsync(clipId: number, url: string) {
  console.log(`Starting processing for clip ${clipId} from ${url}`);
  
  // Simulate delay
  setTimeout(async () => {
    try {
      // Use OpenAI to generate a "viral" title based on mock analysis
      // In reality, we'd transcribe the video here using OpenAI Audio API
      // But since we don't have the video file, we'll mock the analysis part
      // and just use the LLM to generate a catchy title for the URL context
      
      const completion = await openai.chat.completions.create({
        model: "gpt-5.1",
        messages: [
          { role: "system", content: "You are a viral content analyzer. Generate a viral, catchy title for a video from this URL. Keep it short." },
          { role: "user", content: `URL: ${url}` }
        ],
      });

      const viralTitle = completion.choices[0]?.message?.content || "Viral Clip";

      await storage.updateClip(clipId, {
        status: "completed",
        title: viralTitle,
        processedUrl: "https://example.com/mock-processed-clip.mp4", // Mock
        viralScore: Math.floor(Math.random() * 100),
        transcript: "Mock transcript of the video content..."
      });
      console.log(`Finished processing clip ${clipId}`);
    } catch (e) {
      console.error("Processing failed", e);
      await storage.updateClip(clipId, { status: "failed" });
    }
  }, 5000); // 5 seconds delay
}
