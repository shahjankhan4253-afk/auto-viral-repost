import { db } from "./db";
import {
  users, connectedAccounts, clips, reposts,
  type User, type InsertUser,
  type ConnectedAccount, type InsertConnectedAccount,
  type Clip, type InsertClip,
  type Repost, type InsertRepost
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User>;
  
  // Connected Accounts
  getConnectedAccounts(userId: number): Promise<ConnectedAccount[]>;
  createConnectedAccount(account: InsertConnectedAccount): Promise<ConnectedAccount>;
  deleteConnectedAccount(id: number): Promise<void>;
  
  // Clips
  getClips(userId: number): Promise<Clip[]>;
  getClip(id: number): Promise<Clip | undefined>;
  createClip(clip: InsertClip): Promise<Clip>;
  updateClip(id: number, updates: Partial<Clip>): Promise<Clip>;
  
  // Reposts
  getReposts(userId: number): Promise<Repost[]>;
  createRepost(repost: InsertRepost): Promise<Repost>;
}

export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(desc(users.createdAt));
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User> {
    const [user] = await db.update(users).set(updates).where(eq(users.id, id)).returning();
    return user;
  }

  // Connected Accounts
  async getConnectedAccounts(userId: number): Promise<ConnectedAccount[]> {
    return await db.select().from(connectedAccounts).where(eq(connectedAccounts.userId, userId));
  }

  async createConnectedAccount(account: InsertConnectedAccount): Promise<ConnectedAccount> {
    const [newAccount] = await db.insert(connectedAccounts).values(account).returning();
    return newAccount;
  }

  async deleteConnectedAccount(id: number): Promise<void> {
    await db.delete(connectedAccounts).where(eq(connectedAccounts.id, id));
  }

  // Clips
  async getClips(userId: number): Promise<Clip[]> {
    return await db.select().from(clips).where(eq(clips.userId, userId)).orderBy(desc(clips.createdAt));
  }

  async getClip(id: number): Promise<Clip | undefined> {
    const [clip] = await db.select().from(clips).where(eq(clips.id, id));
    return clip;
  }

  async createClip(clip: InsertClip): Promise<Clip> {
    const [newClip] = await db.insert(clips).values(clip).returning();
    return newClip;
  }

  async updateClip(id: number, updates: Partial<Clip>): Promise<Clip> {
    const [updatedClip] = await db.update(clips).set(updates).where(eq(clips.id, id)).returning();
    return updatedClip;
  }

  // Reposts
  async getReposts(userId: number): Promise<Repost[]> {
    return await db.select().from(reposts).where(eq(reposts.userId, userId)).orderBy(desc(reposts.createdAt));
  }

  async createRepost(repost: InsertRepost): Promise<Repost> {
    const [newRepost] = await db.insert(reposts).values(repost).returning();
    return newRepost;
  }
}

export const storage = new DatabaseStorage();
