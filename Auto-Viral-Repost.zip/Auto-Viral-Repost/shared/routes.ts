import { z } from 'zod';
import { insertUserSchema, insertConnectedAccountSchema, insertClipSchema, insertRepostSchema, users, connectedAccounts, clips, reposts } from './schema';

// Shared Error Schemas
export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  }),
  forbidden: z.object({
    message: z.string(),
  }),
};

export const api = {
  auth: {
    register: {
      method: 'POST' as const,
      path: '/api/auth/register',
      input: insertUserSchema,
      responses: {
        201: z.custom<typeof users.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    login: {
      method: 'POST' as const,
      path: '/api/auth/login',
      input: z.object({
        username: z.string(),
        password: z.string(),
      }),
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        401: errorSchemas.unauthorized,
      },
    },
    logout: {
      method: 'POST' as const,
      path: '/api/auth/logout',
      responses: {
        200: z.object({ message: z.string() }),
      },
    },
    me: {
      method: 'GET' as const,
      path: '/api/auth/me',
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        401: errorSchemas.unauthorized,
      },
    },
  },
  users: {
    list: {
      method: 'GET' as const,
      path: '/api/users',
      responses: {
        200: z.array(z.custom<typeof users.$inferSelect>()),
        403: errorSchemas.forbidden,
      },
    },
    updatePlan: {
      method: 'PATCH' as const,
      path: '/api/users/plan',
      input: z.object({
        subscriptionPlan: z.enum(['free', 'pro']),
      }),
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        403: errorSchemas.forbidden,
      },
    },
  },
  connectedAccounts: {
    list: {
      method: 'GET' as const,
      path: '/api/connected-accounts',
      responses: {
        200: z.array(z.custom<typeof connectedAccounts.$inferSelect>()),
      },
    },
    connect: {
      method: 'POST' as const,
      path: '/api/connected-accounts',
      input: insertConnectedAccountSchema.omit({ userId: true }),
      responses: {
        201: z.custom<typeof connectedAccounts.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/connected-accounts/:id',
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
  },
  clips: {
    list: {
      method: 'GET' as const,
      path: '/api/clips',
      responses: {
        200: z.array(z.custom<typeof clips.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/clips',
      input: insertClipSchema.omit({ userId: true }),
      responses: {
        201: z.custom<typeof clips.$inferSelect>(),
        400: errorSchemas.validation,
        403: errorSchemas.forbidden, // Usage limit exceeded
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/clips/:id',
      responses: {
        200: z.custom<typeof clips.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
  },
  reposts: {
    list: {
      method: 'GET' as const,
      path: '/api/reposts',
      responses: {
        200: z.array(z.custom<typeof reposts.$inferSelect>()),
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
