import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Import Chat Models from Integration
export * from "./models/chat";

// === USERS ===
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(), // Hashed
  username: text("username").notNull(),
  subscriptionPlan: text("subscription_plan").notNull().default("free"), // 'free' | 'pro'
  role: text("role").notNull().default("user"), // 'user' | 'admin'
  credits: integer("credits").default(1), // Daily clip limit for free users
  autoRepostEnabled: boolean("auto_repost_enabled").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

// === CONNECTED ACCOUNTS ===
export const connectedAccounts = pgTable("connected_accounts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  platform: text("platform").notNull(), // 'twitter', 'youtube', 'instagram'
  accessToken: text("access_token").notNull(),
  refreshToken: text("refresh_token"),
  platformUserId: text("platform_user_id"),
  platformUsername: text("platform_username"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertConnectedAccountSchema = createInsertSchema(connectedAccounts).omit({ id: true, createdAt: true });
export type ConnectedAccount = typeof connectedAccounts.$inferSelect;
export type InsertConnectedAccount = z.infer<typeof insertConnectedAccountSchema>;

// === CLIPS ===
export const clips = pgTable("clips", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  originalUrl: text("original_url").notNull(),
  processedUrl: text("processed_url"), // Path to generated clip
  title: text("title"),
  status: text("status").notNull().default("pending"), // 'pending' | 'processing' | 'completed' | 'failed'
  viralScore: integer("viral_score"),
  transcript: text("transcript"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertClipSchema = createInsertSchema(clips).omit({ id: true, createdAt: true, processedUrl: true, status: true, viralScore: true, transcript: true });
export type Clip = typeof clips.$inferSelect;
export type InsertClip = z.infer<typeof insertClipSchema>;

// === REPOSTS ===
export const reposts = pgTable("reposts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  clipId: integer("clip_id").notNull().references(() => clips.id),
  targetPlatform: text("target_platform").notNull(), // 'twitter', 'youtube', 'instagram'
  status: text("status").notNull().default("scheduled"), // 'scheduled' | 'posted' | 'failed'
  scheduledTime: timestamp("scheduled_time"),
  postedUrl: text("posted_url"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertRepostSchema = createInsertSchema(reposts).omit({ id: true, createdAt: true });
export type Repost = typeof reposts.$inferSelect;
export type InsertRepost = z.infer<typeof insertRepostSchema>;

// === RELATIONS ===
export const usersRelations = relations(users, ({ many }) => ({
  connectedAccounts: many(connectedAccounts),
  clips: many(clips),
  reposts: many(reposts),
}));

export const connectedAccountsRelations = relations(connectedAccounts, ({ one }) => ({
  user: one(users, {
    fields: [connectedAccounts.userId],
    references: [users.id],
  }),
}));

export const clipsRelations = relations(clips, ({ one, many }) => ({
  user: one(users, {
    fields: [clips.userId],
    references: [users.id],
  }),
  reposts: many(reposts),
}));

export const repostsRelations = relations(reposts, ({ one }) => ({
  user: one(users, {
    fields: [reposts.userId],
    references: [users.id],
  }),
  clip: one(clips, {
    fields: [reposts.clipId],
    references: [clips.id],
  }),
}));
