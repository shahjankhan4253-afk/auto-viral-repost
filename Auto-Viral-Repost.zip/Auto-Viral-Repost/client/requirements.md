## Packages
framer-motion | Smooth page transitions and layout animations
recharts | Analytics charts for the dashboard
date-fns | Date formatting for tables and lists

## Notes
Tailwind Config:
- Fonts: Outfit (display), DM Sans (body)
- Colors: Deep midnight blue background with vibrant violet accents
