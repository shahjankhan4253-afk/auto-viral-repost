import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/hooks/use-auth";
import { useReposts } from "@/hooks/use-reposts";
import { useConnectedAccounts } from "@/hooks/use-connected-accounts";
import { Repeat, Clock, CheckCircle2, XCircle, AlertCircle } from "lucide-react";
import { format } from "date-fns";

export default function RepostPage() {
  const { user } = useAuth();
  const { reposts, isLoading } = useReposts();
  const { accounts } = useConnectedAccounts();
  
  const isPro = user?.subscriptionPlan === "pro";

  return (
    <DashboardLayout>
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold font-display">Auto Repost</h1>
        <p className="text-muted-foreground">Configure automatic reposting to your connected platforms.</p>
      </div>

      <Card className={`border-primary/20 ${!isPro ? 'opacity-80' : ''}`}>
        <CardHeader className="flex flex-row items-center justify-between">
          <div className="space-y-1">
            <CardTitle className="flex items-center gap-2">
              <Repeat className="w-5 h-5 text-primary" />
              Auto Reposting
            </CardTitle>
            <CardDescription>
              Automatically post generated clips to all connected platforms.
              {!isPro && <span className="text-primary font-medium ml-1"> (Pro Plan Only)</span>}
            </CardDescription>
          </div>
          <Switch disabled={!isPro || accounts.length === 0} checked={user?.autoRepostEnabled && isPro} />
        </CardHeader>
      </Card>

      <div className="space-y-4">
        <h2 className="text-xl font-bold">Repost History</h2>
        
        <div className="bg-card rounded-xl border border-border overflow-hidden">
          <div className="grid grid-cols-4 p-4 bg-muted/30 font-medium text-sm text-muted-foreground">
            <div>Clip</div>
            <div>Platform</div>
            <div>Scheduled For</div>
            <div className="text-right">Status</div>
          </div>
          
          <div className="divide-y divide-border">
            {isLoading ? (
              <div className="p-8 text-center text-muted-foreground">Loading history...</div>
            ) : reposts.length === 0 ? (
              <div className="p-8 text-center text-muted-foreground">
                <Clock className="w-8 h-8 mx-auto mb-2 opacity-50" />
                No reposts scheduled or completed yet.
              </div>
            ) : (
              reposts.map((repost) => (
                <div key={repost.id} className="grid grid-cols-4 p-4 items-center text-sm">
                  <div className="font-medium truncate">Clip #{repost.clipId}</div>
                  <div className="capitalize">{repost.targetPlatform}</div>
                  <div className="text-muted-foreground">
                    {repost.scheduledTime ? format(new Date(repost.scheduledTime), "MMM d, HH:mm") : "-"}
                  </div>
                  <div className="flex justify-end">
                    <StatusBadge status={repost.status} />
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}

function StatusBadge({ status }: { status: string }) {
  if (status === "posted") {
    return (
      <span className="flex items-center gap-1 text-emerald-500 bg-emerald-500/10 px-2 py-1 rounded-full text-xs font-medium">
        <CheckCircle2 className="w-3 h-3" /> Posted
      </span>
    );
  }
  if (status === "failed") {
    return (
      <span className="flex items-center gap-1 text-red-500 bg-red-500/10 px-2 py-1 rounded-full text-xs font-medium">
        <XCircle className="w-3 h-3" /> Failed
      </span>
    );
  }
  return (
    <span className="flex items-center gap-1 text-blue-500 bg-blue-500/10 px-2 py-1 rounded-full text-xs font-medium">
      <Clock className="w-3 h-3" /> Scheduled
    </span>
  );
}
