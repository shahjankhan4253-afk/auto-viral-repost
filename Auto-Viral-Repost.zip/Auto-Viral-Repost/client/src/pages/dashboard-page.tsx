import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { StatCard } from "@/components/ui/stat-card";
import { useClips } from "@/hooks/use-clips";
import { useAuth } from "@/hooks/use-auth";
import { useConnectedAccounts } from "@/hooks/use-connected-accounts";
import { Video, Share2, TrendingUp, Zap } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function DashboardPage() {
  const { user } = useAuth();
  const { clips } = useClips();
  const { accounts } = useConnectedAccounts();

  const completedClips = clips.filter(c => c.status === "completed").length;
  const pendingClips = clips.filter(c => c.status === "processing").length;
  const viralScoreAvg = completedClips > 0 
    ? Math.round(clips.reduce((acc, curr) => acc + (curr.viralScore || 0), 0) / completedClips)
    : 0;

  return (
    <DashboardLayout>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold font-display">Dashboard</h1>
          <p className="text-muted-foreground mt-1">Welcome back, {user?.username}. Here's what's happening.</p>
        </div>
        <Link href="/clips">
          <Button className="gap-2 shadow-lg shadow-primary/25">
            <Video className="w-4 h-4" />
            Create New Clip
          </Button>
        </Link>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Daily Credits" 
          value={user?.credits || 0} 
          icon={Zap} 
          description={user?.subscriptionPlan === "pro" ? "Unlimited access" : "Refreshes daily"}
        />
        <StatCard 
          title="Active Clips" 
          value={completedClips} 
          icon={Video} 
          trend={pendingClips > 0 ? `+${pendingClips} processing` : undefined}
        />
        <StatCard 
          title="Viral Score" 
          value={viralScoreAvg} 
          icon={TrendingUp} 
          description="Avg. potential impact"
        />
        <StatCard 
          title="Platforms" 
          value={accounts.length} 
          icon={Share2} 
          description="Connected accounts"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recent Clips */}
        <Card className="border-none shadow-md">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Recent Clips</CardTitle>
            <Link href="/clips" className="text-sm text-primary hover:underline">View All</Link>
          </CardHeader>
          <CardContent>
            {clips.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No clips yet. Start generating!
              </div>
            ) : (
              <div className="space-y-4">
                {clips.slice(0, 5).map((clip) => (
                  <div key={clip.id} className="flex items-center gap-4 p-3 rounded-xl hover:bg-muted/50 transition-colors border border-transparent hover:border-border">
                    <div className="w-12 h-12 rounded-lg bg-secondary flex items-center justify-center shrink-0">
                      <Video className="w-6 h-6 text-muted-foreground" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium truncate">{clip.title || "Untitled Clip"}</h4>
                      <p className="text-xs text-muted-foreground truncate">{clip.originalUrl}</p>
                    </div>
                    <div className={`px-2 py-1 rounded-full text-xs font-medium 
                      ${clip.status === 'completed' ? 'bg-emerald-500/10 text-emerald-500' : 
                        clip.status === 'processing' ? 'bg-blue-500/10 text-blue-500' : 'bg-red-500/10 text-red-500'}`}>
                      {clip.status}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Subscription Status */}
        <Card className="border-none shadow-md bg-gradient-to-br from-card to-secondary/30">
          <CardHeader>
            <CardTitle>Subscription Plan</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-2xl font-bold font-display capitalize">{user?.subscriptionPlan} Plan</h3>
                <p className="text-muted-foreground text-sm">
                  {user?.subscriptionPlan === "free" ? "Basic features active" : "All pro features unlocked"}
                </p>
              </div>
              <div className="bg-primary/10 p-3 rounded-full">
                <Zap className="w-8 h-8 text-primary" />
              </div>
            </div>
            
            <div className="space-y-3 mb-6">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Clip Limit</span>
                <span className="font-medium">{user?.subscriptionPlan === "pro" ? "Unlimited" : "1 per day"}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Auto-Repost</span>
                <span className="font-medium">{user?.subscriptionPlan === "pro" ? "Enabled" : "Disabled"}</span>
              </div>
            </div>

            <Link href="/subscription">
              <Button variant={user?.subscriptionPlan === "pro" ? "outline" : "default"} className="w-full">
                {user?.subscriptionPlan === "pro" ? "Manage Subscription" : "Upgrade to Pro"}
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
