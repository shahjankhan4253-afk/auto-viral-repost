import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Check, Zap } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useUserPlan } from "@/hooks/use-user-plan";

export default function SubscriptionPage() {
  const { user } = useAuth();
  const { updatePlanMutation } = useUserPlan();

  const currentPlan = user?.subscriptionPlan;

  const handleUpgrade = (plan: "free" | "pro") => {
    updatePlanMutation.mutate(plan);
  };

  return (
    <DashboardLayout>
      <div className="text-center space-y-4 mb-12">
        <h1 className="text-4xl font-bold font-display">Simple Pricing</h1>
        <p className="text-muted-foreground text-lg">Choose the plan that fits your viral needs.</p>
      </div>

      <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
        {/* Free Plan */}
        <Card className={`relative border-2 ${currentPlan === 'free' ? 'border-primary shadow-2xl shadow-primary/10' : 'border-border'}`}>
          <CardHeader>
            <CardTitle className="text-2xl">Starter</CardTitle>
            <CardDescription>Perfect for testing the waters</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="text-4xl font-bold font-display">$0 <span className="text-lg font-normal text-muted-foreground">/mo</span></div>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-sm"><Check className="w-4 h-4 text-green-500" /> 1 Clip Per Day</li>
              <li className="flex items-center gap-2 text-sm"><Check className="w-4 h-4 text-green-500" /> 1 Connected Account</li>
              <li className="flex items-center gap-2 text-sm text-muted-foreground"><Check className="w-4 h-4 text-muted-foreground" /> Manual Reposting Only</li>
              <li className="flex items-center gap-2 text-sm text-muted-foreground"><Check className="w-4 h-4 text-muted-foreground" /> Standard Support</li>
            </ul>
          </CardContent>
          <CardFooter>
            <Button 
              className="w-full" 
              variant={currentPlan === 'free' ? "outline" : "default"}
              disabled={currentPlan === 'free' || updatePlanMutation.isPending}
              onClick={() => handleUpgrade('free')}
            >
              {currentPlan === 'free' ? "Current Plan" : "Downgrade"}
            </Button>
          </CardFooter>
        </Card>

        {/* Pro Plan */}
        <Card className={`relative border-2 ${currentPlan === 'pro' ? 'border-primary shadow-2xl shadow-primary/20 scale-105' : 'border-border'}`}>
          {currentPlan !== 'pro' && (
            <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-gradient-to-r from-primary to-purple-500 text-white px-4 py-1 rounded-full text-xs font-bold uppercase tracking-wide">
              Most Popular
            </div>
          )}
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-2">
              Pro Creator
              <Zap className="w-5 h-5 text-yellow-400 fill-yellow-400" />
            </CardTitle>
            <CardDescription>For serious growth hacking</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="text-4xl font-bold font-display">$29 <span className="text-lg font-normal text-muted-foreground">/mo</span></div>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-sm"><Check className="w-4 h-4 text-primary" /> Unlimited Clips</li>
              <li className="flex items-center gap-2 text-sm"><Check className="w-4 h-4 text-primary" /> Unlimited Connected Accounts</li>
              <li className="flex items-center gap-2 text-sm"><Check className="w-4 h-4 text-primary" /> Auto-Repost Enabled</li>
              <li className="flex items-center gap-2 text-sm"><Check className="w-4 h-4 text-primary" /> Priority Processing</li>
            </ul>
          </CardContent>
          <CardFooter>
            <Button 
              className="w-full bg-primary hover:bg-primary/90" 
              disabled={currentPlan === 'pro' || updatePlanMutation.isPending}
              onClick={() => handleUpgrade('pro')}
            >
              {currentPlan === 'pro' ? "Current Plan" : "Upgrade Now"}
            </Button>
          </CardFooter>
        </Card>
      </div>
    </DashboardLayout>
  );
}
