import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { useConnectedAccounts } from "@/hooks/use-connected-accounts";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useState } from "react";
import { SiYoutube, SiInstagram, SiX } from "react-icons/si";
import { Trash2, Plus } from "lucide-react";
import { useForm } from "react-hook-form";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

const platformIcons: Record<string, any> = {
  youtube: SiYoutube,
  instagram: SiInstagram,
  twitter: SiX,
};

const platformColors: Record<string, string> = {
  youtube: "text-red-600 bg-red-600/10",
  instagram: "text-pink-600 bg-pink-600/10",
  twitter: "text-black dark:text-white bg-zinc-100 dark:bg-zinc-800",
};

const connectSchema = z.object({
  platform: z.enum(["youtube", "instagram", "twitter"]),
  platformUsername: z.string().min(1, "Username is required"),
  accessToken: z.string().min(1, "Access Token (Demo) is required"),
});

export default function ConnectPage() {
  const { accounts, connectMutation, disconnectMutation } = useConnectedAccounts();
  const [open, setOpen] = useState(false);

  const form = useForm<z.infer<typeof connectSchema>>({
    resolver: zodResolver(connectSchema),
    defaultValues: {
      platform: "twitter",
      platformUsername: "",
      accessToken: "",
    },
  });

  const onSubmit = (data: z.infer<typeof connectSchema>) => {
    connectMutation.mutate(data, {
      onSuccess: () => {
        setOpen(false);
        form.reset();
      },
    });
  };

  return (
    <DashboardLayout>
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold font-display">Connect Platforms</h1>
        <p className="text-muted-foreground">Link your social media accounts to enable auto-reposting.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Connected Accounts List */}
        {accounts.map((account) => {
          const Icon = platformIcons[account.platform];
          return (
            <Card key={account.id} className="relative overflow-hidden group">
              <CardHeader className="flex flex-row items-center gap-4">
                <div className={`p-3 rounded-xl ${platformColors[account.platform]}`}>
                  <Icon className="w-6 h-6" />
                </div>
                <div>
                  <CardTitle className="capitalize">{account.platform}</CardTitle>
                  <CardDescription>@{account.platformUsername}</CardDescription>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2 text-sm text-emerald-500 bg-emerald-500/10 px-3 py-1 rounded-full w-fit mb-4">
                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  Connected
                </div>
                <Button 
                  variant="destructive" 
                  size="sm" 
                  className="w-full opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={() => disconnectMutation.mutate(account.id)}
                  disabled={disconnectMutation.isPending}
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Disconnect
                </Button>
              </CardContent>
            </Card>
          );
        })}

        {/* Add New Account Card */}
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Card className="border-dashed border-2 flex flex-col items-center justify-center p-8 cursor-pointer hover:bg-muted/50 transition-colors min-h-[200px]">
              <div className="w-16 h-16 rounded-full bg-secondary flex items-center justify-center mb-4 group-hover:bg-primary/10 group-hover:text-primary transition-colors">
                <Plus className="w-8 h-8 text-muted-foreground group-hover:text-primary" />
              </div>
              <h3 className="font-semibold text-lg">Connect New</h3>
              <p className="text-sm text-muted-foreground text-center mt-2">Add YouTube, Instagram, or X</p>
            </Card>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Connect Platform</DialogTitle>
              <DialogDescription>
                In demo mode, you can connect mock accounts by providing a username and a dummy token.
              </DialogDescription>
            </DialogHeader>

            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="platform"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Platform</FormLabel>
                      <FormControl>
                        <select 
                          {...field}
                          className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                        >
                          <option value="twitter">X (Twitter)</option>
                          <option value="youtube">YouTube</option>
                          <option value="instagram">Instagram</option>
                        </select>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="platformUsername"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Username Handle</FormLabel>
                      <FormControl>
                        <Input placeholder="viral_king" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="accessToken"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Access Token (Demo)</FormLabel>
                      <FormControl>
                        <Input type="password" placeholder="mock_token_123" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button type="submit" className="w-full" disabled={connectMutation.isPending}>
                  {connectMutation.isPending ? "Connecting..." : "Connect Account"}
                </Button>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
