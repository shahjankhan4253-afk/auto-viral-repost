import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { useClips } from "@/hooks/use-clips";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Video, Loader2, PlayCircle, Share2, Wand2 } from "lucide-react";
import { useState } from "react";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";

export default function ClipsPage() {
  const { clips, isLoading, createClipMutation } = useClips();
  const [url, setUrl] = useState("");
  const { toast } = useToast();

  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!url) return;
    
    // Simple validation for demo
    if (!url.startsWith("http")) {
      toast({ title: "Invalid URL", description: "Please enter a valid video URL", variant: "destructive" });
      return;
    }

    createClipMutation.mutate({ originalUrl: url }, {
      onSuccess: () => setUrl("")
    });
  };

  return (
    <DashboardLayout>
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold font-display">Viral Clip Generator</h1>
          <p className="text-muted-foreground text-lg">Paste a YouTube or video URL, and our AI will extract the most viral moments.</p>
        </div>

        {/* Generator Input */}
        <Card className="border-primary/20 shadow-lg shadow-primary/5">
          <CardContent className="p-6">
            <form onSubmit={handleGenerate} className="flex gap-4">
              <Input 
                placeholder="https://youtube.com/watch?v=..." 
                className="h-12 text-lg"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
              />
              <Button type="submit" size="lg" className="h-12 px-8 gap-2 bg-gradient-to-r from-primary to-purple-500" disabled={createClipMutation.isPending}>
                {createClipMutation.isPending ? <Loader2 className="animate-spin" /> : <Wand2 className="w-5 h-5" />}
                Generate Magic
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Clips List */}
        <div className="space-y-4">
          <h2 className="text-xl font-bold">Your Clips</h2>
          
          {isLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : clips.length === 0 ? (
            <div className="text-center py-12 border-2 border-dashed rounded-xl bg-card/50">
              <Video className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="font-medium text-lg">No clips yet</h3>
              <p className="text-muted-foreground">Generate your first clip above to get started.</p>
            </div>
          ) : (
            <div className="grid gap-4">
              {clips.map((clip) => (
                <Card key={clip.id} className="overflow-hidden">
                  <div className="flex flex-col sm:flex-row sm:items-center p-4 gap-4">
                    {/* Thumbnail/Preview Placeholder */}
                    <div className="w-full sm:w-48 aspect-video bg-zinc-900 rounded-lg flex items-center justify-center relative group cursor-pointer">
                      {clip.status === "processing" ? (
                        <Loader2 className="w-8 h-8 text-primary animate-spin" />
                      ) : clip.status === "completed" ? (
                        <>
                          <PlayCircle className="w-10 h-10 text-white opacity-80 group-hover:scale-110 transition-transform" />
                          <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors rounded-lg" />
                        </>
                      ) : (
                        <div className="text-red-500 font-medium text-sm">Failed</div>
                      )}
                    </div>

                    <div className="flex-1 min-w-0 space-y-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-lg truncate">{clip.title || "Processing Clip..."}</h3>
                        <span className={`text-xs px-2 py-0.5 rounded-full capitalize font-medium
                          ${clip.status === 'completed' ? 'bg-emerald-500/10 text-emerald-500' : 
                            clip.status === 'processing' ? 'bg-blue-500/10 text-blue-500' : 'bg-zinc-500/10 text-zinc-500'}`}>
                          {clip.status}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground truncate">{clip.originalUrl}</p>
                      <p className="text-xs text-muted-foreground">Created {format(new Date(clip.createdAt || new Date()), "MMM d, yyyy")}</p>
                      
                      {clip.viralScore && (
                        <div className="mt-2 flex items-center gap-2">
                          <div className="h-2 w-32 bg-secondary rounded-full overflow-hidden">
                            <div className="h-full bg-gradient-to-r from-blue-500 to-purple-500" style={{ width: `${clip.viralScore}%` }} />
                          </div>
                          <span className="text-xs font-medium">{clip.viralScore} Viral Score</span>
                        </div>
                      )}
                    </div>

                    {clip.status === "completed" && (
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" className="gap-2">
                          <PlayCircle className="w-4 h-4" /> Preview
                        </Button>
                        <Button size="sm" className="gap-2">
                          <Share2 className="w-4 h-4" /> Repost
                        </Button>
                      </div>
                    )}
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
