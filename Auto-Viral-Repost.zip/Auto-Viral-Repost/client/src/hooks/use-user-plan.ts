import { useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useUserPlan() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const updatePlanMutation = useMutation({
    mutationFn: async (plan: "free" | "pro") => {
      const res = await fetch(api.users.updatePlan.path, {
        method: api.users.updatePlan.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ subscriptionPlan: plan }),
      });
      if (!res.ok) throw new Error("Failed to update plan");
      return res.json();
    },
    onSuccess: (updatedUser) => {
      queryClient.setQueryData([api.auth.me.path], updatedUser);
      toast({ 
        title: "Plan updated!", 
        description: `You are now on the ${updatedUser.subscriptionPlan.toUpperCase()} plan.` 
      });
    },
    onError: (error: Error) => {
      toast({ title: "Update failed", description: error.message, variant: "destructive" });
    },
  });

  return {
    updatePlanMutation,
  };
}
