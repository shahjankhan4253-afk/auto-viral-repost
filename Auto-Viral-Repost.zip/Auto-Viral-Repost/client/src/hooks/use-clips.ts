import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { Clip, InsertClip } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export function useClips() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: clips = [], isLoading } = useQuery<Clip[]>({
    queryKey: [api.clips.list.path],
    queryFn: async () => {
      const res = await fetch(api.clips.list.path);
      if (!res.ok) throw new Error("Failed to fetch clips");
      return res.json();
    },
    refetchInterval: 5000, // Poll for status updates
  });

  const createClipMutation = useMutation({
    mutationFn: async (data: Omit<InsertClip, "userId">) => {
      const res = await fetch(api.clips.create.path, {
        method: api.clips.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to create clip");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.clips.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.auth.me.path] }); // Update credits
      toast({ title: "Clip processing started", description: "We are generating your viral clip." });
    },
    onError: (error: Error) => {
      toast({ title: "Failed to create clip", description: error.message, variant: "destructive" });
    },
  });

  return {
    clips,
    isLoading,
    createClipMutation,
  };
}
