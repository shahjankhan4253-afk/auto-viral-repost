import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { ConnectedAccount, InsertConnectedAccount } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export function useConnectedAccounts() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: accounts = [], isLoading } = useQuery<ConnectedAccount[]>({
    queryKey: [api.connectedAccounts.list.path],
    queryFn: async () => {
      const res = await fetch(api.connectedAccounts.list.path);
      if (!res.ok) throw new Error("Failed to fetch connected accounts");
      return res.json();
    },
  });

  const connectMutation = useMutation({
    mutationFn: async (data: Omit<InsertConnectedAccount, "userId">) => {
      const res = await fetch(api.connectedAccounts.connect.path, {
        method: api.connectedAccounts.connect.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to connect account");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.connectedAccounts.list.path] });
      toast({ title: "Account connected", description: "Platform connected successfully." });
    },
    onError: (error: Error) => {
      toast({ title: "Connection failed", description: error.message, variant: "destructive" });
    },
  });

  const disconnectMutation = useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.connectedAccounts.delete.path, { id });
      const res = await fetch(url, { method: api.connectedAccounts.delete.method });
      if (!res.ok) throw new Error("Failed to disconnect account");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.connectedAccounts.list.path] });
      toast({ title: "Account disconnected", description: "Platform removed successfully." });
    },
    onError: (error: Error) => {
      toast({ title: "Disconnect failed", description: error.message, variant: "destructive" });
    },
  });

  return {
    accounts,
    isLoading,
    connectMutation,
    disconnectMutation,
  };
}
