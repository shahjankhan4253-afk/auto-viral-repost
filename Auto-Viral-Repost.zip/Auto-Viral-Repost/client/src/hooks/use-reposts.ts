import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { Repost } from "@shared/schema";

export function useReposts() {
  const { data: reposts = [], isLoading } = useQuery<Repost[]>({
    queryKey: [api.reposts.list.path],
    queryFn: async () => {
      const res = await fetch(api.reposts.list.path);
      if (!res.ok) throw new Error("Failed to fetch reposts");
      return res.json();
    },
  });

  return {
    reposts,
    isLoading,
  };
}
